const pool = require('../../configs/db');

const create = async ({id, title, description = null, systemPrompt, userId}) => {
    await pool.query(
        `INSERT INTO workflows (id, user_id, title, description, system_prompt)
         VALUES (?, ?, ?, ?, ?)`,
        [id, userId, title, description, systemPrompt],
    );

    const [rows] = await pool.query(
        `SELECT id, user_id, title, description, system_prompt, is_active, created_at, updated_at
         FROM workflows
         WHERE id = ?
         LIMIT 1`,
        [id],
    );

    return rows[0];
}

const listWorkflowsByUser = async (userId) => {
    const [rows] = await pool.query(
        `SELECT id, user_id, title, description, system_prompt, is_active, created_at, updated_at
         FROM workflows
         WHERE user_id = ?
           AND is_active = 1
         ORDER BY created_at DESC`,
        [userId],
    );

    return rows;
}

const getWorkflowById = async (id, userId) => {
    const [rows] = await pool.query(
        `SELECT id, user_id, title, description, system_prompt, is_active, created_at, updated_at
         FROM workflows
         WHERE id = ?
           AND user_id = ?
           AND is_active = 1
         LIMIT 1`,
        [id, userId],
    );

    return rows[0];
}

const createExecutionRun = async ({id, workflowId = null, userId, goalPrompt, status='PENDING'}) => {
    await pool.query(
        `INSERT INTO execution_runs (id, workflow_id, user_id, goal_prompt, status)
         VALUES (?, ?, ?, ?, ?)`,
        [id, workflowId, userId, goalPrompt, status],
    );

    return getExecutionById(id, userId);
}

const getExecutionById = async (id, userId = null) => {
    let sql = `
        SELECT id, workflow_id, user_id, goal_prompt, status, started_at, completed_at,
               total_tokens, total_cost_usd, created_at
        FROM execution_runs
        WHERE id = ?`;
    const values = [id];

    if (userId) {
        sql += ' AND user_id = ?';
        values.push(userId);
    }

    sql += ' LIMIT 1';

    const [rows] = await pool.query(sql, values);

    return rows[0];
}

const updateExecutionRunStatus = async (id, status, extra = {}) => {
    const updates = ['status = ?'];
    const values = [status];

    if (status === 'RUNNING') {
        updates.push('started_at = COALESCE(started_at, NOW())');
    } else if (status === 'COMPLETED' || status === 'FAILED') {
        updates.push('completed_at = NOW()');
    }

    if (extra.totalTokens !== undefined) {
        updates.push('total_tokens = ?');
        values.push(extra.totalTokens);
    }

    if (extra.totalCostUsd !== undefined) {
        updates.push('total_cost_usd = ?');
        values.push(extra.totalCostUsd);
    }

    values.push(id);

    const sql = `UPDATE execution_runs SET ${updates.join(', ')} WHERE id = ?`;
    const [result] = await pool.query(sql, values);

    return result;
}

const incrementExecutionRunUsage = async (id, {totalTokens = 0, totalCostUsd = 0} = {}) => {
    const tokens = Math.max(0, Number.parseInt(totalTokens, 10) || 0);
    const cost = Math.max(0, Number(totalCostUsd) || 0);

    if (tokens === 0 && cost === 0) {
        return {
            affectedRows: 0,
        };
    }

    const [result] = await pool.query(
        `UPDATE execution_runs
         SET total_tokens = total_tokens + ?,
             total_cost_usd = total_cost_usd + ?
         WHERE id = ?`,
        [tokens, cost, id],
    );

    return result;
}

const listExecutionRunsByUser = async (userId) => {
    const [rows] = await pool.query(
        `SELECT id, workflow_id, goal_prompt, status, started_at, completed_at, total_tokens, total_cost_usd, created_at
         FROM execution_runs
         WHERE user_id = ?
         ORDER BY created_at DESC`,
        [userId],
    );

    return rows;
}

const createExecutionLog = async ({id, runId, level = 'INFO', source = 'SYSTEM', message}) => {
    await pool.query(
        `INSERT INTO execution_logs (id, run_id, level, source, message)
         VALUES (?, ?, ?, ?, ?)`,
        [id, runId, level, source, message],
    );
}

const listExecutionLogsByRunId = async (runId) => {
    const [rows] = await pool.query(
        `SELECT id, run_id, level, source, message, created_at
         FROM execution_logs
         WHERE run_id = ?
         ORDER BY created_at ASC`,
        [runId],
    );

    return rows;
}

const listTaskNodesByRunId = async (runId) => {
    const [rows] = await pool.query(
        `SELECT id, run_id, node_key, title, instruction, dependencies, status,
                assigned_tool, tool_input, tool_output, error_message, retry_count,
                execution_time_ms, started_at, completed_at, created_at
         FROM task_nodes
         WHERE run_id = ?
         ORDER BY created_at ASC`,
        [runId],
    );

    return rows;
}

const listLatestTaskNodesByRunId = async (runId) => {
    const [rows] = await pool.query(
        `SELECT id, run_id, node_key, title, instruction, dependencies, status,
                assigned_tool, tool_input, tool_output, error_message, retry_count,
                execution_time_ms, started_at, completed_at, created_at
         FROM task_nodes
         WHERE run_id = ?
           AND created_at = (
               SELECT MAX(created_at)
               FROM task_nodes
               WHERE run_id = ?
           )
         ORDER BY created_at ASC`,
        [runId, runId],
    );

    return rows;
}

const updateTaskNode = async (id, updates = {}) => {
    const updateFields = [];
    const values = [];

    if (updates.status !== undefined) {
        updateFields.push('status = ?');
        values.push(updates.status);
    }

    if (updates.errorMessage !== undefined) {
        updateFields.push('error_message = ?');
        values.push(updates.errorMessage);
    }

    if (updates.toolOutput !== undefined) {
        updateFields.push('tool_output = ?');
        values.push(JSON.stringify(updates.toolOutput));
    }

    if (updates.toolInput !== undefined) {
        updateFields.push('tool_input = ?');
        values.push(JSON.stringify(updates.toolInput));
    }

    if (updates.retryCount !== undefined) {
        updateFields.push('retry_count = ?');
        values.push(updates.retryCount);
    }

    if (updates.executionTimeMs !== undefined) {
        updateFields.push('execution_time_ms = ?');
        values.push(updates.executionTimeMs);
    }

    if (updates.startedAt !== undefined) {
        updateFields.push('started_at = ?');
        values.push(updates.startedAt);
    }

    if (updates.completedAt !== undefined) {
        updateFields.push('completed_at = ?');
        values.push(updates.completedAt);
    }

    if (!updateFields.length) {
        return {
            affectedRows: 0,
        };
    }

    values.push(id);

    const sql = `UPDATE task_nodes SET ${updateFields.join(', ')} WHERE id = ?`;
    const [result] = await pool.query(sql, values);

    return result;
}

const bulkInsertTaskNodes = async (tasks) => {
    if (!tasks.length) {
        return {
            affectedRows: 0,
        };
    }

    const placeholders = tasks.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
    const values = tasks.flatMap((task) => [
        task.id,
        task.runId,
        task.nodeKey,
        task.title,
        task.instruction,
        JSON.stringify(task.dependencies || []),
        task.assignedTool,
        JSON.stringify(task.toolInput || {}),
        task.status || 'PENDING',
        task.retryCount || 0,
    ]);

    const sql = `
        INSERT INTO task_nodes (
            id,
            run_id,
            node_key,
            title,
            instruction,
            dependencies,
            assigned_tool,
            tool_input,
            status,
            retry_count
        )
        VALUES ${placeholders}`;

    const [result] = await pool.query(sql, values);

    return result;
}

module.exports = {
    create,
    listWorkflowsByUser,
    getWorkflowById,
    createExecutionRun,
    updateExecutionRunStatus,
    incrementExecutionRunUsage,
    getExecutionById,
    listExecutionRunsByUser,
    createExecutionLog,
    listExecutionLogsByRunId,
    listTaskNodesByRunId,
    listLatestTaskNodesByRunId,
    updateTaskNode,
    bulkInsertTaskNodes,
}
